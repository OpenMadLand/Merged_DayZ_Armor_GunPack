DayZ Realistic Military Armor (HD, armor 512x256, icons 128x128)
Leather=Field Medic | Chainmail=Riot Police | Iron=Wasteland Security | Gold=Hazmat | Diamond=Special Forces | Netherite=Black Ops
